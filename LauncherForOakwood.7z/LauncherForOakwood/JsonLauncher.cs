﻿namespace LauncherForOakwood
{
    class JsonLauncher
    {
        public string gamepath { get; set; }
        public int width { get; set; }
        public int height { get; set; }
        public bool fullscreen { get; set; }
        public int antialiasing { get; set; }
    }
}
