﻿namespace LauncherForOakwood
{
    class JsonClient
    {
        public string temp_nickname { get; set; }
    }
}
